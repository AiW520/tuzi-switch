/**
 * KBNoteEditor - 知识库笔记编辑器
 *
 * 标题编辑 + 来源信息（可折叠） + 标签选择 + Markdown 编辑器
 * 自动保存（500ms 防抖）
 * 支持语音朗读、导出 Markdown
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { SkillDSLParser } from '../ai-input-bar/skill-dsl-parser';
import {
  Volume2,
  VolumeX,
  Download,
  Paperclip,
  ChevronDown,
  ChevronRight,
  Globe,
  User,
  Calendar,
  ExternalLink,
  BookOpen,
  Lock,
} from 'lucide-react';
import { MarkdownEditor, MarkdownEditorRef } from '../MarkdownEditor';
import { MediaLibraryModal } from '../media-library';
import { KBTagSelector } from './KBTagSelector';
import { McpToolSelector } from './McpToolSelector';
import { useCanvasAudioPlayback } from '../../hooks/useCanvasAudioPlayback';
import { knowledgeBaseService } from '../../services/knowledge-base-service';
import { exportNoteAsMarkdown } from '../../services/kb-import-export-service';
import { openMusicPlayerToolAndPlay } from '../../services/tool-launch-service';
import { createReadingPlaybackSource } from '../../services/reading-playback-source';
import { buildBlockAssetEmbedMarkdown } from '../../utils/markdown-asset-embeds';
import './knowledge-base-editor.scss';
import type { Asset } from '../../types/asset.types';
import { SelectionMode } from '../../types/asset.types';
import type { KBNote, KBTag, KBTagWithCount } from '../../types/knowledge-base.types';
import { HoverTip } from '../shared/hover';

interface KBNoteEditorProps {
  note: KBNote | null;
  allTags: KBTagWithCount[];
  noteTags: KBTag[];
  /** 是否只读模式（系统内置 Skill 笔记） */
  readOnly?: boolean;
  /** 是否在 Skill 目录下（用于显示 DSL 解析状态提示） */
  isSkillDirectory?: boolean;
  onUpdateNote: (id: string, updates: { title?: string; content?: string }) => void;
  onSetNoteTags: (noteId: string, tagIds: string[]) => void;
  onCreateTag: (name: string) => Promise<KBTag>;
}

function formatDate(ts: number): string {
  return new Date(ts).toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export const KBNoteEditor: React.FC<KBNoteEditorProps> = ({
  note,
  allTags,
  noteTags,
  readOnly = false,
  isSkillDirectory = false,
  onUpdateNote,
  onSetNoteTags,
  onCreateTag,
}) => {
  const [title, setTitle] = useState('');
  const [metadataCollapsed, setMetadataCollapsed] = useState(false);
  const [isMediaLibraryOpen, setIsMediaLibraryOpen] = useState(false);
  /** DSL 解析状态：null=不显示, true=符合规范, false=不符合规范 */
  const [isDSLContent, setIsDSLContent] = useState<boolean | null>(null);
  const dslCheckTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const editorRef = useRef<MarkdownEditorRef>(null);
  const currentNoteIdRef = useRef<string | null>(null);

  const playback = useCanvasAudioPlayback();
  const isSpeechSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  // 标签 IDs
  const selectedTagIds = useMemo(() => noteTags.map((t) => t.id), [noteTags]);

  // MCP 输出类型（仅 Skill 目录下有效）
  const [outputType, setOutputType] = useState<'image' | 'text' | 'video' | 'audio' | 'ppt' | undefined>(undefined);

  // 笔记切换时同步 outputType
  useEffect(() => {
    if (note && isSkillDirectory) {
setOutputType((note.metadata?.outputType as 'image' | 'text' | 'video' | 'audio' | 'ppt' | undefined) || undefined);
    } else {
      setOutputType(undefined);
    }
  }, [note?.id, isSkillDirectory]); // eslint-disable-line react-hooks/exhaustive-deps

  // 笔记元数据
  const metadata = (note as any)?.metadata;
  const hasSourceInfo = metadata && (metadata.sourceUrl || metadata.author || metadata.domain);

  // 切换笔记时重置标题、语音和 DSL 状态
  useEffect(() => {
    const currentSourceId = note ? `kb-note:${note.id}` : null;
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
    }
    if (dslCheckTimeoutRef.current) {
      clearTimeout(dslCheckTimeoutRef.current);
      dslCheckTimeoutRef.current = null;
    }
    if (note) {
      setTitle(note.title);
      currentNoteIdRef.current = note.id;
      // 切换笔记时立即检测 DSL 状态
      if (isSkillDirectory && !readOnly) {
        const content = note.content || '';
        setIsDSLContent(content.trim() ? SkillDSLParser.isDSLContent(content) : null);
      } else {
        setIsDSLContent(null);
      }
    } else {
      setTitle('');
      currentNoteIdRef.current = null;
      setIsDSLContent(null);
    }
    if (
      playback.mediaType === 'reading' &&
      currentSourceId &&
      playback.activeReadingSourceId?.startsWith(currentSourceId)
    ) {
      playback.stopPlayback();
    }
  }, [note?.id, isSkillDirectory, readOnly]); // eslint-disable-line react-hooks/exhaustive-deps

  // 标题变化时防抖保存
  const handleTitleChange = useCallback(
    (newTitle: string) => {
      setTitle(newTitle);
      if (!note) return;
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        onUpdateNote(note.id, { title: newTitle });
      }, 500);
    },
    [note, onUpdateNote]
  );

  // 内容变化时防抖保存，并在 Skill 目录下检测 DSL 状态
  const handleContentChange = useCallback(
    (content: string) => {
      if (!note) return;
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        onUpdateNote(note.id, { content });
      }, 500);

      // Skill 目录下：debounce 500ms 检测 DSL 规范
      if (isSkillDirectory && !readOnly) {
        if (dslCheckTimeoutRef.current) clearTimeout(dslCheckTimeoutRef.current);
        dslCheckTimeoutRef.current = setTimeout(() => {
          if (!content.trim()) {
            setIsDSLContent(null);
          } else {
            setIsDSLContent(SkillDSLParser.isDSLContent(content));
          }
        }, 500);
      }
    },
    [note, onUpdateNote, isSkillDirectory, readOnly]
  );



  // 输出类型变化
  const handleOutputTypeChange = useCallback(
    (newOutputType: 'image' | 'text' | 'video' | 'audio' | 'ppt' | undefined) => {
      if (!note) return;
      setOutputType(newOutputType);
      // 立即保存到元数据
      const updatedMetadata = { ...note.metadata, outputType: newOutputType };
      if (!newOutputType) {
        delete updatedMetadata.outputType;
      }
      knowledgeBaseService.updateNote(note.id, {
        metadata: updatedMetadata,
      });
    },
    [note]
  );

  // 标签变化
  const handleTagsChange = useCallback(
    (tagIds: string[]) => {
      if (!note) return;
      onSetNoteTags(note.id, tagIds);
    },
    [note, onSetNoteTags]
  );

  // 语音朗读切换
  const handleSpeechToggle = useCallback(() => {
    if (!note) return;
    const sourceId = `kb-note:${note.id}`;
    const isCurrentReading =
      playback.mediaType === 'reading'
      && playback.activeReadingSourceId?.startsWith(sourceId);

    if (isCurrentReading) {
      if (playback.playing) {
        playback.pausePlayback();
      } else {
        void playback.resumePlayback();
      }
      return;
    }

    const readingSource = createReadingPlaybackSource({
      elementId: sourceId,
      title: note.title || '知识库笔记',
      content: [note.title, note.content].filter(Boolean).join('\n\n'),
      origin: {
        kind: 'kb-note',
        id: note.id,
      },
    });
    if (!readingSource) return;

    void openMusicPlayerToolAndPlay({
      source: readingSource,
      queue: [readingSource],
    });
  }, [note, playback]);

  // 导出 Markdown
  const handleExportMarkdown = useCallback(async () => {
    if (!note) return;
    const result = await exportNoteAsMarkdown(note.id);
    if (!result) return;

    const blob = new Blob([result.content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = result.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [note]);

  const handleOpenMediaLibrary = useCallback(() => {
    if (readOnly) return;
    setIsMediaLibraryOpen(true);
  }, [readOnly]);

  const handleInsertAsset = useCallback((asset: Asset) => {
    editorRef.current?.insertMarkdown(buildBlockAssetEmbedMarkdown(asset));
    setIsMediaLibraryOpen(false);
  }, []);

  // 清理定时器
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      if (dslCheckTimeoutRef.current) clearTimeout(dslCheckTimeoutRef.current);
    };
  }, []);

  if (!note) {
    return (
      <div className="kb-note-editor kb-note-editor--empty">
        <div className="kb-note-editor__placeholder">
          <div className="kb-note-editor__placeholder-icon">
            <BookOpen size={64} strokeWidth={1} />
          </div>
          <h3 className="kb-note-editor__placeholder-title">无笔记选中</h3>
          <p className="kb-note-editor__placeholder-text">
            选择左侧的一篇笔记开始编辑，或者创建一个新笔记
          </p>
        </div>
      </div>
    );
  }

  const currentReadingSourceId = `kb-note:${note.id}`;
  const isCurrentReading =
    playback.mediaType === 'reading'
    && playback.activeReadingSourceId?.startsWith(currentReadingSourceId);

  return (
    <div className={`kb-note-editor ${readOnly ? 'kb-note-editor--readonly' : ''}`}>
      {/* 只读模式提示条 */}
      {readOnly && (
        <div className="kb-note-editor__readonly-banner">
          <Lock size={14} />
          <span>系统内置 Skill，不可修改</span>
        </div>
      )}
      {/* 标题行 */}
      <div className="kb-note-editor__title-row">
        <input
          className="kb-note-editor__title"
          value={title}
          onChange={(e) => !readOnly && handleTitleChange(e.target.value)}
          placeholder="笔记标题"
          readOnly={readOnly}
        />
        <div className="kb-note-editor__actions">
          {isSpeechSupported && (
            <HoverTip
              content={
                isCurrentReading
                  ? playback.playing
                    ? '暂停朗读'
                    : '继续朗读'
                  : '语音朗读'
              }
              showArrow={false}
            >
              <button
                className={`kb-note-editor__action-btn ${isCurrentReading ? 'kb-note-editor__action-btn--active' : ''}`}
                onClick={handleSpeechToggle}
              >
                {isCurrentReading && playback.playing ? (
                  <VolumeX size={14} />
                ) : (
                  <Volume2 size={14} />
                )}
              </button>
            </HoverTip>
          )}
          {isSpeechSupported && isCurrentReading && (
            <HoverTip content="停止朗读" showArrow={false}>
              <button
                className="kb-note-editor__action-btn kb-note-editor__action-btn--danger"
                onClick={playback.stopPlayback}
              >
                ■
              </button>
            </HoverTip>
          )}
          <HoverTip content="导出 Markdown" showArrow={false}>
            <button
              className="kb-note-editor__action-btn"
              onClick={handleExportMarkdown}
            >
              <Download size={14} />
            </button>
          </HoverTip>
          {!readOnly && (
            <HoverTip content="插入素材" showArrow={false}>
              <button
                className="kb-note-editor__action-btn"
                onClick={handleOpenMediaLibrary}
              >
                <Paperclip size={14} />
              </button>
            </HoverTip>
          )}
        </div>
      </div>

      {/* 来源信息区域 - 可折叠 */}
      {hasSourceInfo && (
        <div className={`kb-note-editor__metadata-section ${metadataCollapsed ? 'kb-note-editor__metadata-section--collapsed' : ''}`}>
          <HoverTip
            content={metadataCollapsed ? '展开来源信息' : '收起来源信息'}
            showArrow={false}
          >
            <button
              className="kb-note-editor__metadata-toggle"
              onClick={() => setMetadataCollapsed(!metadataCollapsed)}
            >
              {metadataCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
              <span>来源信息</span>
            </button>
          </HoverTip>

          {/* 折叠时显示简要信息 */}
          {metadataCollapsed && (
            <div className="kb-note-editor__metadata-collapsed">
              {metadata.author && (
                <span className="kb-note-editor__metadata-collapsed-item">
                  <User size={10} />
                  <span>{metadata.author}</span>
                </span>
              )}
              {metadata.sourceUrl && (
                <HoverTip content={metadata.sourceUrl} showArrow={false}>
                  <a
                    href={metadata.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="kb-note-editor__metadata-collapsed-link"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink size={10} />
                    <span>{metadata.domain || metadata.sourceUrl}</span>
                  </a>
                </HoverTip>
              )}
            </div>
          )}

          {/* 展开时显示完整信息 */}
          {!metadataCollapsed && (
            <div className="kb-note-editor__metadata-body">
              {/* 标签选择器 */}
              <div className="kb-note-editor__tags">
                <KBTagSelector
                  allTags={allTags}
                  selectedTagIds={selectedTagIds}
                  onSelectedChange={handleTagsChange}
                  onCreateTag={onCreateTag}
                />
              </div>

              {/* 元数据信息行 */}
              <div className="kb-note-editor__metadata-info">
                {metadata.domain && (
                  <span className="kb-note-editor__metadata-item">
                    {metadata.faviconUrl ? (
                      <img
                        src={metadata.faviconUrl}
                        alt=""
                        className="kb-note-editor__favicon"
                        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                      />
                    ) : (
                      <Globe size={12} />
                    )}
                    <span>{metadata.domain}</span>
                  </span>
                )}
                {metadata.author && (
                  <span className="kb-note-editor__metadata-item">
                    <User size={12} />
                    <span>{metadata.author}</span>
                  </span>
                )}
                {metadata.publishedAt && (
                  <span className="kb-note-editor__metadata-item">
                    <Calendar size={12} />
                    <span>{metadata.publishedAt}</span>
                  </span>
                )}
              </div>
              {metadata.sourceUrl && (
                <a
                  href={metadata.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="kb-note-editor__source-link"
                >
                  {metadata.sourceUrl}
                </a>
              )}
              {metadata.description && (
                <p className="kb-note-editor__metadata-desc">{metadata.description}</p>
              )}
            </div>
          )}
        </div>
      )}

      {/* 无来源信息时仍显示标签 */}
      {!hasSourceInfo && (
        <div className="kb-note-editor__tags">
          <KBTagSelector
            allTags={allTags}
            selectedTagIds={selectedTagIds}
            onSelectedChange={handleTagsChange}
            onCreateTag={onCreateTag}
          />
        </div>
      )}

      {/* MCP 工具绑定（仅在 Skill 目录下显示） */}
      {isSkillDirectory && (
        <div className="kb-note-editor__mcp-tools">
          <McpToolSelector
            outputType={outputType}
            onOutputTypeChange={handleOutputTypeChange}
            readOnly={readOnly}
          />
        </div>
      )}

      {/* Markdown 编辑器 */}
      <div className="kb-note-editor__content">
        <MarkdownEditor
          key={note.id}
          ref={editorRef}
          markdown={note.content}
          onChange={readOnly ? undefined : handleContentChange}
          placeholder="开始写点什么..."
          showModeSwitch={!readOnly}
          readOnly={readOnly}
          enableAssetEmbeds={true}
          enableAssetLibraryImagePicker={!readOnly}
          className="kb-note-markdown"
        />
      </div>

      {/* DSL 解析状态提示条（仅在 Skill 目录且非只读时显示） */}
      {isSkillDirectory && !readOnly && isDSLContent !== null && (
        <div className={`kb-note-editor__dsl-status ${isDSLContent ? 'kb-note-editor__dsl-status--valid' : 'kb-note-editor__dsl-status--fallback'}`}>
          {isDSLContent
            ? '✓ 已识别为工作流 DSL（正则解析），将直接执行'
            : '⚡ 将由 AI 解析为工作流（大模型解析）'
          }
        </div>
      )}

      {isMediaLibraryOpen && (
        <MediaLibraryModal
          isOpen={isMediaLibraryOpen}
          onClose={() => setIsMediaLibraryOpen(false)}
          mode={SelectionMode.SELECT}
          onSelect={handleInsertAsset}
          selectButtonText="插入到笔记"
        />
      )}
    </div>
  );
};
