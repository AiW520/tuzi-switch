export { KnowledgeBaseDrawer } from './KnowledgeBaseDrawer';
