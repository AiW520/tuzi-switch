/**
 * ChatDrawer Component
 *
 * Main chat drawer component using local lightweight chat UI types.
 */

import React, {
  useState,
  useCallback,
  useEffect,
  useMemo,
  useImperativeHandle,
  forwardRef,
  useRef,
  Suspense,
} from 'react';
import { CloseIcon, AddIcon, ViewListIcon } from 'tdesign-icons-react';
import { ATTACHED_ELEMENT_CLASS_NAME } from '@plait/core';
import { SessionList } from './SessionList';
import { ChatDrawerTrigger } from './ChatDrawerTrigger';
import { ModelSelector } from './ModelSelector';
import { EnhancedChatInput } from './EnhancedChatInput';
import { chatStorageService } from '../../services/chat-storage-service';
import { useChatHandler } from '../../hooks/useChatHandler';
import {
  createModelRef,
  providerProfilesSettings,
  resolveInvocationRoute,
  settingsManager,
  type ModelRef,
} from '../../utils/settings-manager';
import { useDrawnix } from '../../hooks/use-drawnix';
import { useChatDrawer } from '../../contexts/ChatDrawerContext';
import type { DrawerGenerationSubmitParams } from '../../contexts/ChatDrawerContext';
import type {
  ChatDrawerProps,
  ChatDrawerRef,
  ChatSession,
  ChatSessionGenerationState,
  WorkflowMessageData,
  WorkflowMessageParams,
  AgentLogEntry,
  ChatMessage as ChatMessageType,
  SelectedContentItem,
} from '../../types/chat.types';
import { MessageRole, MessageStatus } from '../../types/chat.types';
import type { Task } from '../../types/task.types';
import type { Message } from '../../types/chat-ui.types';
import { useTextSelection } from '../../hooks/useTextSelection';
import { applyTaskUpdateToWorkflowMessage } from '../../utils/workflow-task-sync';
import { resolveWorkflowSessionTarget } from '../../utils/chat-drawer-session-target';
import {
  getLatestWorkflowImageReferences,
  shouldUseImplicitWorkflowReferences,
} from './workflow-media-results';

import { analytics } from '../../utils/umami-analytics';
import {
  canResumeTuziRequest,
  prepareTuziManagedRoute,
} from '../../services/tuzi-managed-route-gate';
import { resolveDrawerGenerationRoute } from './drawer-generation-route';
import { HoverTip } from '../shared';
import './chat-drawer.scss';

const ChatMessagesArea = React.lazy(() => import('./ChatMessagesArea'));

// 工作流消息的特殊标记前缀
const WORKFLOW_MESSAGE_PREFIX = '[[WORKFLOW_MESSAGE]]';

/**
 * 根据工具名称生成描述
 */
function getToolDescription(
  toolName: string,
  args?: Record<string, unknown>
): string {
  switch (toolName) {
    case 'generate_image':
      return `生成图片: ${((args?.prompt as string) || '').substring(
        0,
        30
      )}...`;
    case 'generate_video':
      return `生成视频: ${((args?.prompt as string) || '').substring(
        0,
        30
      )}...`;
    case 'generate_audio':
      return `生成音频: ${((args?.prompt as string) || '').substring(
        0,
        30
      )}...`;
    case 'generate_text':
      return `生成文本: ${((args?.prompt as string) || '').substring(
        0,
        30
      )}...`;
    case 'generate_grid_image':
      return `生成宫格图: ${((args?.theme as string) || '').substring(
        0,
        30
      )}...`;
    case 'canvas_insertion':
      return '插入到画布';
    case 'generate_mermaid':
      return '生成流程图';
    case 'generate_mindmap':
      return '生成思维导图';
    default:
      return `执行 ${toolName}`;
  }
}

// 抽屉宽度缓存 key
const DRAWER_WIDTH_CACHE_KEY = 'chat-drawer-width';
// 默认宽度（与 SCSS 中的 50vw 对应）
const DEFAULT_DRAWER_WIDTH = Math.max(375, window.innerWidth * 0.5);
// 最小宽度
const MIN_DRAWER_WIDTH = 375;
const MAX_DRAFT_CONTENT_ITEMS = 8;
const MAX_DRAFT_INLINE_URL_LENGTH = 2048;

function getDefaultSessionModelSelection(): {
  model: string | undefined;
  modelRef: ModelRef | null;
} {
  const route = resolveInvocationRoute('text');
  return {
    model: route.modelId,
    modelRef: createModelRef(route.profileId, route.modelId),
  };
}

function getSessionModelSelection(session?: ChatSession | null): {
  model: string | undefined;
  modelRef: ModelRef | null;
} {
  if (session?.sessionModel) {
    return {
      model: session.sessionModel,
      modelRef:
        session.sessionModelRef || createModelRef(null, session.sessionModel),
    };
  }

  return getDefaultSessionModelSelection();
}

function sanitizeDraftUploadedContent(
  items: SelectedContentItem[]
): SelectedContentItem[] {
  return items.slice(0, MAX_DRAFT_CONTENT_ITEMS).map((item) => {
    const next: SelectedContentItem = {
      type: item.type,
      name: item.name,
    };

    if (
      item.url &&
      (!item.url.startsWith('data:') ||
        item.url.length <= MAX_DRAFT_INLINE_URL_LENGTH)
    ) {
      next.url = item.url;
    }
    if (
      item.maskImage &&
      (!item.maskImage.startsWith('data:') ||
        item.maskImage.length <= MAX_DRAFT_INLINE_URL_LENGTH)
    ) {
      next.maskImage = item.maskImage;
    }
    if (item.text) {
      next.text = item.text.slice(0, 4096);
    }
    if (typeof item.width === 'number') {
      next.width = item.width;
    }
    if (typeof item.height === 'number') {
      next.height = item.height;
    }

    return next;
  });
}

function getMessageStatusForWorkflow(
  workflow: WorkflowMessageData
): MessageStatus {
  switch (workflow.status) {
    case 'completed':
      return MessageStatus.SUCCESS;
    case 'failed':
    case 'cancelled':
      return MessageStatus.FAILED;
    default:
      return MessageStatus.STREAMING;
  }
}

function findWorkflowMessageIdInMap(
  workflowMessages: Map<string, WorkflowMessageData>,
  workflowId: string
): string | null {
  for (const [msgId, workflow] of workflowMessages.entries()) {
    if (workflow.id === workflowId) {
      return msgId;
    }
  }
  return null;
}

export const ChatDrawer = forwardRef<ChatDrawerRef, ChatDrawerProps>(
  ({ defaultOpen = false, onOpenChange }, ref) => {
    // Initialize state from cache synchronously to prevent flash
    const [isOpen, setIsOpen] = useState(() => {
      const cached = chatStorageService.getDrawerState();
      return cached.isOpen ?? defaultOpen;
    });
    const [sessions, setSessions] = useState<ChatSession[]>([]);
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const activeSessionIdRef = useRef<string | null>(null);
    const updateActiveSessionId = useCallback((sessionId: string | null) => {
      activeSessionIdRef.current = sessionId;
      setActiveSessionId(sessionId);
    }, []);
    const [showSessions, setShowSessions] = useState(false);

    // 抽屉宽度状态（从缓存初始化）
    const [drawerWidth, setDrawerWidth] = useState(() => {
      const cached = localStorage.getItem(DRAWER_WIDTH_CACHE_KEY);
      if (cached) {
        const width = parseInt(cached, 10);
        if (!isNaN(width) && width >= MIN_DRAWER_WIDTH) {
          return Math.min(width, window.innerWidth - 60);
        }
      }
      return DEFAULT_DRAWER_WIDTH;
    });
    // 是否正在拖动
    const [isDragging, setIsDragging] = useState(false);
    // 拖动手柄 ref
    const resizeHandleRef = useRef<HTMLDivElement>(null);

    // 临时模型选择（仅在当前会话中有效，不影响全局设置）
    // 默认值从当前文本路由读取，保留供应商来源信息
    const [sessionModel, setSessionModel] = useState<string | undefined>(() => {
      return getDefaultSessionModelSelection().model;
    });
    const [sessionModelRef, setSessionModelRef] = useState<ModelRef | null>(
      () => getDefaultSessionModelSelection().modelRef
    );

    // 工作流消息状态：存储当前会话中的工作流数据
    const [workflowMessages, setWorkflowMessages] = useState<
      Map<string, WorkflowMessageData>
    >(new Map());
    const workflowMessagesRef = useRef(workflowMessages);
    // 当前正在更新的工作流消息 ID
    const currentWorkflowMsgIdRef = useRef<string | null>(null);
    const currentWorkflowSessionIdRef = useRef<string | null>(null);
    const pendingStoredWorkflowTaskSyncRef = useRef<Set<string>>(new Set());
    // 正在重试的工作流 ID
    const [retryingWorkflowId, setRetryingWorkflowId] = useState<string | null>(
      null
    );
    const [replyTarget, setReplyTarget] = useState<{
      messageId: string;
      workflow: WorkflowMessageData;
    } | null>(null);
    const clearWorkflowState = useCallback(() => {
      const emptyWorkflowMessages = new Map<string, WorkflowMessageData>();
      workflowMessagesRef.current = emptyWorkflowMessages;
      setWorkflowMessages(emptyWorkflowMessages);
      currentWorkflowMsgIdRef.current = null;
      currentWorkflowSessionIdRef.current = null;
      setReplyTarget(null);
    }, []);

    // 获取重试执行器和选中内容（从 Context），以及状态同步方法
    const {
      executeRetry,
      selectedContent,
      submitGenerationFromDrawer,
      generationSubmitterReady,
      registerGenerationCredentialGate,
      setIsDrawerOpen: setContextIsOpen,
      setDrawerWidth: setContextDrawerWidth,
    } = useChatDrawer();

    // 同步抽屉状态到 Context（用于视图导航联动）
    useEffect(() => {
      setContextIsOpen(isOpen);
    }, [isOpen, setContextIsOpen]);

    // 同步抽屉宽度到 Context
    useEffect(() => {
      setContextDrawerWidth(drawerWidth);
    }, [drawerWidth, setContextDrawerWidth]);

    // Refs for click outside detection
    const sessionListRef = React.useRef<HTMLDivElement>(null);
    const toggleButtonRef = React.useRef<HTMLButtonElement>(null);

    // Get app state for settings dialog
    const { appState, setAppState } = useDrawnix();

    // 处理拖动调整宽度
    useEffect(() => {
      if (!isDragging) return;

      const handleMouseMove = (e: MouseEvent) => {
        const newWidth = window.innerWidth - e.clientX;
        const clampedWidth = Math.max(
          MIN_DRAWER_WIDTH,
          Math.min(newWidth, window.innerWidth - 60)
        );
        setDrawerWidth(clampedWidth);
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        // 保存到缓存
        localStorage.setItem(DRAWER_WIDTH_CACHE_KEY, String(drawerWidth));
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      // 拖动时禁用文本选择
      document.body.style.userSelect = 'none';
      document.body.style.cursor = 'ew-resize';

      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
      };
    }, [isDragging, drawerWidth]);

    // 窗口大小变化时调整宽度
    useEffect(() => {
      const handleResize = () => {
        const maxWidth = window.innerWidth - 60;
        if (drawerWidth > maxWidth) {
          setDrawerWidth(maxWidth);
        }
      };

      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }, [drawerWidth]);

    // 开始拖动
    const handleResizeStart = useCallback((e: React.MouseEvent) => {
      e.preventDefault();
      setIsDragging(true);
    }, []);

    const loadSessionState = useCallback(
      async (sessionId: string, sessionHint?: ChatSession | null) => {
        const session =
          sessionHint || (await chatStorageService.getSession(sessionId));
        const modelSelection = getSessionModelSelection(session);
        setSessionModel(modelSelection.model);
        setSessionModelRef(modelSelection.modelRef);

        const messages = await chatStorageService.getMessages(sessionId);
        const newWorkflowMessages = new Map<string, WorkflowMessageData>();

        for (const msg of messages) {
          if (msg.workflow) {
            newWorkflowMessages.set(msg.id, msg.workflow);
          }
        }

        workflowMessagesRef.current = newWorkflowMessages;
        setWorkflowMessages(newWorkflowMessages);
        const runningWorkflow = messages.find(
          (m) => m.workflow && m.status === MessageStatus.STREAMING
        );
        currentWorkflowMsgIdRef.current = runningWorkflow?.id || null;
        currentWorkflowSessionIdRef.current = runningWorkflow
          ? sessionId
          : null;
      },
      []
    );

    // 处理工具调用回调
    const handleToolCalls = useCallback(
      async (
        toolCalls: Array<{
          name: string;
          arguments: Record<string, unknown>;
          id?: string;
        }>,
        messageId: string,
        executeTools: () => Promise<
          Array<{
            toolCall: { name: string; arguments: Record<string, unknown> };
            success: boolean;
            data?: unknown;
            error?: string;
            taskId?: string;
          }>
        >,
        aiAnalysis?: string,
        targetSessionId?: string
      ) => {
        // console.log('[ChatDrawer] Tool calls received:', toolCalls.length, 'aiAnalysis:', aiAnalysis?.substring(0, 50));

        // 创建工作流数据
        const workflowId = `workflow-${Date.now()}`;
        const workflowData: WorkflowMessageData = {
          id: workflowId,
          name: 'AI 智能生成',
          generationType: toolCalls[0]?.name.includes('video')
            ? 'video'
            : toolCalls[0]?.name.includes('audio')
            ? 'audio'
            : 'image',
          prompt: aiAnalysis || '',
          aiAnalysis: aiAnalysis,
          count: toolCalls.length,
          steps: toolCalls.map((tc, idx) => ({
            id: `step-${idx}`,
            mcp: tc.name,
            status: 'pending' as const,
            description: getToolDescription(tc.name, tc.arguments),
            args: tc.arguments,
          })),
        };

        // 更新工作流状态
        if (
          !targetSessionId ||
          activeSessionIdRef.current === targetSessionId
        ) {
          setWorkflowMessages((prev) => {
            const newMap = new Map(prev);
            newMap.set(messageId, workflowData);
            return newMap;
          });
          currentWorkflowMsgIdRef.current = messageId;
        }

        // 持久化工作流数据到存储
        chatStorageService.updateMessage(messageId, { workflow: workflowData });

        // 执行工具
        try {
          const results = await executeTools();
          analytics.track('chat_tool_execution_complete', {
            success: true,
            resultCount: results.length,
          });
          analytics.track('ai_modality_used', {
            modality: 'agent',
            action: 'tool_execution_completed',
            source: 'chat_drawer',
            success: true,
            toolCount: toolCalls.length,
            resultCount: results.length,
          });

          // 更新步骤状态
          const updatedWorkflow = {
            ...workflowData,
            steps: workflowData.steps.map((step, idx) => {
              const result = results[idx];
              return {
                ...step,
                status: result?.success
                  ? ('completed' as const)
                  : ('failed' as const),
                error: result?.error,
                result: result?.data,
              };
            }),
          };
          chatStorageService.updateMessage(messageId, {
            workflow: updatedWorkflow,
            status: MessageStatus.SUCCESS,
          });
          if (
            !targetSessionId ||
            activeSessionIdRef.current === targetSessionId
          ) {
            setWorkflowMessages((prev) => {
              const newMap = new Map(prev);
              newMap.set(messageId, updatedWorkflow);
              return newMap;
            });
          }

          // console.log('[ChatDrawer] Tools executed:', results.length);
        } catch (error: any) {
          console.error('[ChatDrawer] Tool execution failed:', error);
          // 标记所有步骤失败
          const updatedWorkflow = {
            ...workflowData,
            steps: workflowData.steps.map((step) => ({
              ...step,
              status: 'failed' as const,
              error: error.message || '执行失败',
            })),
          };
          chatStorageService.updateMessage(messageId, {
            workflow: updatedWorkflow,
            status: MessageStatus.FAILED,
          });
          if (
            !targetSessionId ||
            activeSessionIdRef.current === targetSessionId
          ) {
            setWorkflowMessages((prev) => {
              const newMap = new Map(prev);
              newMap.set(messageId, updatedWorkflow);
              return newMap;
            });
          }
        }
      },
      []
    );

    const chatHandler = useChatHandler({
      sessionId: activeSessionId,
      temporaryModel: sessionModelRef || sessionModel, // 传递临时模型来源
      onToolCalls: handleToolCalls, // 传递工具调用回调
    });

    useEffect(() => {
      workflowMessagesRef.current = workflowMessages;
    }, [workflowMessages]);

    // 使用 ref 存储 sendMessage 函数，避免 useEffect 依赖 chatHandler 导致重复执行
    const sendMessageRef = useRef(chatHandler.sendMessage);

    // Load initial sessions and active session
    useEffect(() => {
      const init = async () => {
        const drawerState = chatStorageService.getDrawerState();
        const loadedSessions = await chatStorageService.getAllSessions();
        setSessions(loadedSessions);

        let activeId: string | null = null;
        if (drawerState.activeSessionId) {
          activeId = drawerState.activeSessionId;
          updateActiveSessionId(drawerState.activeSessionId);
        } else if (loadedSessions.length > 0) {
          activeId = loadedSessions[0].id;
          updateActiveSessionId(loadedSessions[0].id);
        }

        // 加载活动会话的工作流数据
        if (activeId) {
          try {
            const activeSession = loadedSessions.find(
              (session) => session.id === activeId
            );
            await loadSessionState(activeId, activeSession);
          } catch (error) {
            console.error(
              '[ChatDrawer] Failed to load workflow messages:',
              error
            );
          }
        }
      };

      init();
    }, [loadSessionState, updateActiveSessionId]);

    // Save drawer state when it changes
    useEffect(() => {
      activeSessionIdRef.current = activeSessionId;
      chatStorageService.setDrawerState({
        isOpen,
        activeSessionId,
      });
    }, [isOpen, activeSessionId]);

    // Send pending message when session is ready
    useEffect(() => {
      if (
        activeSessionId &&
        pendingMessageRef.current &&
        canResumeTuziRequest(pendingTuziUserRef.current)
      ) {
        const msg = pendingMessageRef.current;
        pendingMessageRef.current = null;
        // Use setTimeout to ensure handler is updated
        setTimeout(() => {
          sendMessageRef.current(msg);
        }, 100);
      }
    }, [activeSessionId]);

    // Send pending message when API key is configured and settings dialog closes
    useEffect(() => {
      // When settings dialog closes, check if we have a pending message and API key
      if (!appState.openSettings && pendingMessageRef.current) {
        const route = resolveInvocationRoute('text');
        if (route.apiKey && canResumeTuziRequest(pendingTuziUserRef.current)) {
          const msg = pendingMessageRef.current;
          pendingMessageRef.current = null;
          // If there's no active session, create one first
          if (!activeSessionId) {
            (async () => {
              const newSession = await chatStorageService.createSession();
              setSessions((prev) => [newSession, ...prev]);
              updateActiveSessionId(newSession.id);
              // Store message again for the session effect to pick up
              pendingMessageRef.current = msg;
            })();
          } else {
            // Send immediately if session exists
            setTimeout(() => {
              sendMessageRef.current(msg);
            }, 100);
          }
        }
      }
    }, [appState.openSettings, activeSessionId, updateActiveSessionId]);

    // Handle Escape key to close drawer
    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && isOpen) {
          setIsOpen(false);
          onOpenChange?.(false);
        }
      };

      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, onOpenChange]);

    // Subscribe to SW workflow events to keep ChatDrawer in sync
    // This ensures ChatDrawer shows the same status as WorkZone when SW updates workflow state
    useEffect(() => {
      let subscription: { unsubscribe: () => void } | null = null;

      const setupWorkflowSync = async () => {
        const { workflowSubmissionService } = await import(
          '../../services/workflow-submission-service'
        );

        subscription = workflowSubmissionService.subscribeToAllEvents(
          (event) => {
            const workflowEvent = event as {
              type: string;
              workflowId: string;
              stepId?: string;
              status?: string;
              result?: unknown;
              error?: string;
              duration?: number;
            };

            // Find workflow in workflowMessages by workflow ID
            setWorkflowMessages((prev) => {
              // Find the message ID that contains this workflow
              let targetMsgId: string | null = null;
              for (const [msgId, wf] of prev.entries()) {
                if (wf.id === workflowEvent.workflowId) {
                  targetMsgId = msgId;
                  break;
                }
              }

              if (!targetMsgId) {
                return prev;
              }

              const workflow = prev.get(targetMsgId);
              if (!workflow) {
                return prev;
              }

              const newMap = new Map(prev);
              let updatedWorkflow: WorkflowMessageData;

              switch (workflowEvent.type) {
                case 'step': {
                  // Update specific step status
                  updatedWorkflow = {
                    ...workflow,
                    steps: workflow.steps.map((step) => {
                      if (step.id === workflowEvent.stepId) {
                        return {
                          ...step,
                          status: (workflowEvent.status ||
                            step.status) as typeof step.status,
                          result: workflowEvent.result ?? step.result,
                          error: workflowEvent.error ?? step.error,
                        };
                      }
                      return step;
                    }),
                  };
                  break;
                }

                case 'steps_added': {
                  // AI 分析返回了后续步骤，添加到工作流中
                  const stepsAddedEvent = workflowEvent as {
                    type: string;
                    workflowId: string;
                    steps?: Array<{
                      id: string;
                      mcp: string;
                      args: Record<string, unknown>;
                      description: string;
                      status: string;
                    }>;
                  };
                  const newSteps = (stepsAddedEvent.steps || []).map(
                    (step) => ({
                      id: step.id,
                      mcp: step.mcp,
                      args: step.args,
                      description: step.description,
                      status: step.status as
                        | 'pending'
                        | 'running'
                        | 'completed'
                        | 'failed'
                        | 'skipped',
                    })
                  );
                  updatedWorkflow = {
                    ...workflow,
                    steps: [...workflow.steps, ...newSteps],
                  };
                  break;
                }

                case 'completed':
                case 'failed': {
                  // Workflow completed or failed - update all pending/running steps
                  const finalStatus =
                    workflowEvent.type === 'completed' ? 'completed' : 'failed';
                  updatedWorkflow = {
                    ...workflow,
                    status: finalStatus,
                    steps: workflow.steps.map((step) => {
                      if (
                        step.status === 'running' ||
                        step.status === 'pending'
                      ) {
                        // For steps with taskId, don't force status change
                        const stepResult = step.result as
                          | { taskId?: string }
                          | undefined;
                        if (stepResult?.taskId) {
                          return step;
                        }
                        return {
                          ...step,
                          status: finalStatus as typeof step.status,
                          error:
                            workflowEvent.type === 'failed'
                              ? workflowEvent.error
                              : undefined,
                        };
                      }
                      return step;
                    }),
                  };
                  break;
                }

                default:
                  return prev;
              }

              newMap.set(targetMsgId, updatedWorkflow);

              // Persist to local storage
              chatStorageService.updateMessage(targetMsgId, {
                workflow: updatedWorkflow,
              });

              return newMap;
            });
          }
        );
      };

      setupWorkflowSync().catch((error) => {
        console.error('[ChatDrawer] Failed to setup workflow sync:', error);
      });

      return () => {
        subscription?.unsubscribe();
      };
    }, []);

    // Handle click outside to close session list
    useEffect(() => {
      if (!showSessions) return;

      const handleClickOutside = (e: MouseEvent) => {
        const target = e.target as HTMLElement;

        // Check if click is inside a TDesign Dialog (rendered outside the component tree)
        const isInDialog = target.closest('.t-dialog') !== null;
        if (isInDialog) {
          return;
        }

        // Check if click is outside session list and toggle button
        if (
          sessionListRef.current &&
          !sessionListRef.current.contains(target) &&
          toggleButtonRef.current &&
          !toggleButtonRef.current.contains(target)
        ) {
          setShowSessions(false);
        }
      };

      // Add small delay to avoid immediate closing when opening
      const timer = setTimeout(() => {
        document.addEventListener('mousedown', handleClickOutside);
      }, 100);

      return () => {
        clearTimeout(timer);
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }, [showSessions]);

    // Toggle drawer
    const handleToggle = useCallback(() => {
      setIsOpen((prev) => {
        const newValue = !prev;
        onOpenChange?.(newValue);
        return newValue;
      });
    }, [onOpenChange]);

    // Close drawer
    const handleClose = useCallback(() => {
      setIsOpen(false);
      onOpenChange?.(false);
    }, [onOpenChange]);

    // Create new session
    const handleNewSession = useCallback(async () => {
      analytics.track('chat_session_create');
      const newSession = await chatStorageService.createSession();
      const defaultModelSelection = getDefaultSessionModelSelection();
      newSession.sessionModel = defaultModelSelection.model;
      newSession.sessionModelRef = defaultModelSelection.modelRef;
      await chatStorageService.updateSession(
        newSession.id,
        {
          sessionModel: defaultModelSelection.model,
          sessionModelRef: defaultModelSelection.modelRef,
          draftInput: '',
          draftUploadedContent: [],
        },
        { preserveUpdatedAt: true }
      );
      setSessions((prev) => [newSession, ...prev]);
      updateActiveSessionId(newSession.id);
      setShowSessions(false);
      clearWorkflowState();
      // 重置为当前默认文本模型
      setSessionModel(defaultModelSelection.model);
      setSessionModelRef(defaultModelSelection.modelRef);
    }, [clearWorkflowState, updateActiveSessionId]);

    // Toggle session list
    const handleToggleSessions = useCallback(() => {
      setShowSessions((prev) => !prev);
    }, []);

    // Select session（从存储中加载工作流数据）
    const handleSelectSession = useCallback(
      async (sessionId: string) => {
        analytics.track('chat_session_select');
        updateActiveSessionId(sessionId);
        setShowSessions(false);
        clearWorkflowState();

        // 从存储中加载会话的消息，提取工作流数据
        try {
          await loadSessionState(sessionId);
        } catch (error) {
          console.error(
            '[ChatDrawer] Failed to load workflow messages:',
            error
          );
          clearWorkflowState();
        }
      },
      [clearWorkflowState, loadSessionState, updateActiveSessionId]
    );

    // Delete session
    const handleDeleteSession = useCallback(
      async (sessionId: string) => {
        analytics.track('chat_session_delete');
        await chatStorageService.deleteSession(sessionId);
        setSessions((prev) => {
          const updated = prev.filter((s) => s.id !== sessionId);
          if (activeSessionId === sessionId) {
            const newActive = updated[0] || null;
            updateActiveSessionId(newActive?.id || null);
            clearWorkflowState();
            if (newActive) {
              void loadSessionState(newActive.id, newActive).catch((error) => {
                console.error(
                  '[ChatDrawer] Failed to load workflow messages:',
                  error
                );
                clearWorkflowState();
              });
            } else {
              const defaultModelSelection = getDefaultSessionModelSelection();
              setSessionModel(defaultModelSelection.model);
              setSessionModelRef(defaultModelSelection.modelRef);
            }
          }
          return updated;
        });
      },
      [
        activeSessionId,
        clearWorkflowState,
        loadSessionState,
        updateActiveSessionId,
      ]
    );

    // Rename session
    const handleRenameSession = useCallback(
      async (sessionId: string, newTitle: string) => {
        analytics.track('chat_session_rename');
        await chatStorageService.updateSession(sessionId, { title: newTitle });
        setSessions((prev) =>
          prev.map((s) => (s.id === sessionId ? { ...s, title: newTitle } : s))
        );
      },
      []
    );

    // Store pending message for retry after session creation or API key config
    const pendingMessageRef = React.useRef<Message | null>(null);
    const pendingTuziUserRef = React.useRef<string | undefined>(undefined);
    const pendingGenerationRef =
      React.useRef<DrawerGenerationSubmitParams | null>(null);
    const isResumingGenerationRef = React.useRef(false);
    const isPreparingGenerationCredentialsRef = React.useRef(false);
    const [providerProfilesRevision, setProviderProfilesRevision] = useState(0);

    useEffect(() => {
      const handleProviderProfilesChange = () => {
        setProviderProfilesRevision((current) => current + 1);
      };
      providerProfilesSettings.addListener(handleProviderProfilesChange);
      return () =>
        providerProfilesSettings.removeListener(handleProviderProfilesChange);
    }, []);

    const handleGenerationSubmit = useCallback(
      async (params: DrawerGenerationSubmitParams): Promise<boolean> => {
        await settingsManager.waitForInitialization();
        const route = resolveDrawerGenerationRoute(params);
        const preparation = await prepareTuziManagedRoute(route);
        pendingTuziUserRef.current = preparation.context?.userId;
        if (preparation.requiresSetup) {
          pendingGenerationRef.current = params;
          setAppState((current) => ({ ...current, openSettings: true }));
          return true;
        }
        if (!route.apiKey || preparation.managedRoute) {
          pendingGenerationRef.current = params;
          isPreparingGenerationCredentialsRef.current = true;
          const preparedRoute = resolveDrawerGenerationRoute(params);
          if (
            preparedRoute.apiKey &&
            (!preparation.managedRoute ||
              preparation.context?.status === 'ready')
          ) {
            window.setTimeout(() => {
              isPreparingGenerationCredentialsRef.current = false;
              setProviderProfilesRevision((current) => current + 1);
            }, 0);
            return true;
          }
          isPreparingGenerationCredentialsRef.current = false;
          setAppState((current) => ({ ...current, openSettings: true }));
          return true;
        }

        pendingGenerationRef.current = null;
        return submitGenerationFromDrawer(params);
      },
      [setAppState, submitGenerationFromDrawer]
    );

    useEffect(() => {
      registerGenerationCredentialGate(handleGenerationSubmit);
      return () => registerGenerationCredentialGate(null);
    }, [handleGenerationSubmit, registerGenerationCredentialGate]);

    useEffect(() => {
      const pending = pendingGenerationRef.current;
      if (
        appState.openSettings ||
        !pending ||
        !generationSubmitterReady ||
        isPreparingGenerationCredentialsRef.current ||
        isResumingGenerationRef.current ||
        !canResumeTuziRequest(pendingTuziUserRef.current) ||
        !resolveDrawerGenerationRoute(pending).apiKey
      ) {
        return;
      }

      pendingGenerationRef.current = null;
      isResumingGenerationRef.current = true;
      void submitGenerationFromDrawer(pending)
        .then((submitted) => {
          if (!submitted) {
            pendingGenerationRef.current = pending;
          }
        })
        .catch((error) => {
          pendingGenerationRef.current = pending;
          console.error(
            '[ChatDrawer] pending generation resume failed:',
            error
          );
        })
        .finally(() => {
          isResumingGenerationRef.current = false;
        });
    }, [
      appState.openSettings,
      generationSubmitterReady,
      providerProfilesRevision,
      submitGenerationFromDrawer,
    ]);

    // Handle send with auto-create session
    const handleSendWrapper = useCallback(
      async (msg: Message) => {
        try {
          analytics.track('chat_message_send', {
            hasImages: msg.parts.some((p) => p.type === 'image_url'), // Message parts uses image_url usually
          });
          analytics.track('ai_modality_used', {
            modality: 'agent',
            action: 'message_send',
            source: 'chat_drawer',
            hasImages: msg.parts.some((p) => p.type === 'image_url'),
            partCount: msg.parts.length,
            textLength: msg.parts
              .filter((part) => part.type === 'text')
              .reduce(
                (total, part) =>
                  total + String((part as any).text || '').length,
                0
              ),
          });
          // Check if API key is configured
          const route = resolveInvocationRoute('text');
          const preparation = await prepareTuziManagedRoute(route);
          pendingTuziUserRef.current = preparation.context?.userId;
          const preparedRoute = resolveInvocationRoute('text');
          if (
            preparation.requiresSetup ||
            !preparedRoute.apiKey ||
            (preparation.managedRoute &&
              preparation.context?.status !== 'ready')
          ) {
            // Store message for sending after API key is configured
            pendingMessageRef.current = msg;
            setAppState((current) => ({ ...current, openSettings: true }));
            return;
          }

          // Clear pending message since we're processing it
          pendingMessageRef.current = null;

          if (!activeSessionId) {
            const newSession = await chatStorageService.createSession();
            setSessions((prev) => [newSession, ...prev]);
            updateActiveSessionId(newSession.id);
            // Store message to send after session is created
            pendingMessageRef.current = msg;
            return;
          }

          await chatHandler.sendMessage(msg);
        } catch (error) {
          console.error('[ChatDrawer] send message failed:', error);
          pendingMessageRef.current = msg;
        }
      },
      [activeSessionId, chatHandler, setAppState, updateActiveSessionId]
    );

    sendMessageRef.current = handleSendWrapper;

    // 发送工作流消息
    const handleSendWorkflowMessage = useCallback(
      async (params: WorkflowMessageParams) => {
        const {
          context,
          workflow,
          textModel,
          autoOpen = true,
          appendToCurrentSession,
          appendToSessionId,
        } = params;
        // 根据 autoOpen 参数决定是否打开抽屉
        if (autoOpen) {
          setIsOpen(true);
          onOpenChange?.(true);
        }

        // 如果传入了文本模型，设置为当前会话的临时模型
        if (textModel) {
          setSessionModel(textModel);
        }

        const sessionTarget = resolveWorkflowSessionTarget(
          activeSessionId,
          appendToCurrentSession,
          appendToSessionId
        );

        // 构建显示用的消息内容
        // 区分：选中的文本元素（作为 prompt）vs 用户输入的指令（额外要求）
        const displayParts: string[] = [];

        // 1. 显示用户输入的指令（额外要求）- 核心内容
        if (context.userInstruction) {
          displayParts.push(context.userInstruction);
        }

        // 2. 显示选中的文本元素（作为生成 prompt 的来源）
        if (context.selection.texts.length > 0) {
          displayParts.push(
            `\n📝 选中的文本:\n${context.selection.texts.join('\n')}`
          );
        }

        // 3. 如果两者都没有，显示 finalPrompt
        if (
          context.selection.texts.length === 0 &&
          !context.userInstruction &&
          context.finalPrompt
        ) {
          displayParts.push(`\n提示词:\n${context.finalPrompt}`);
        }

        // 4. 显示模型和参数信息 - 辅助信息，放在最后并用分隔线
        const metaInfo: string[] = [];
        const modelInfo = context.model.isExplicit
          ? `模型: ${context.model.id}`
          : `模型: ${context.model.id} (默认)`;
        metaInfo.push(modelInfo);

        if (context.params.count > 1) {
          metaInfo.push(`数量: ${context.params.count}`);
        }

        if (metaInfo.length > 0) {
          displayParts.push(`\n---\n${metaInfo.join('  •  ')}`);
        }

        const userDisplayText = displayParts.join('\n');

        // 生成标题优先级：
        // 1. finalPrompt（最终用于生成的提示词，最能代表任务内容）
        // 2. 选中的文本元素（作为生成 prompt 的来源）
        // 3. 用户指令冒号后面的内容（如 "生成灵感图: xxx" 取 "xxx"）
        // 4. 模型名称（兜底）
        let titleText = '新任务';
        if (context.finalPrompt) {
          titleText = context.finalPrompt;
        } else if (context.selection.texts.length > 0) {
          titleText = context.selection.texts[0];
        } else if (context.userInstruction) {
          // 提取冒号后面的内容作为标题
          const colonIndex = context.userInstruction.indexOf(':');
          const chineseColonIndex = context.userInstruction.indexOf('：');
          const actualColonIndex =
            colonIndex >= 0 && chineseColonIndex >= 0
              ? Math.min(colonIndex, chineseColonIndex)
              : Math.max(colonIndex, chineseColonIndex);

          if (
            actualColonIndex >= 0 &&
            actualColonIndex < context.userInstruction.length - 1
          ) {
            titleText = context.userInstruction
              .substring(actualColonIndex + 1)
              .trim();
          } else {
            titleText = context.userInstruction;
          }
        } else if (context.model.id) {
          titleText = `模型: ${context.model.id}`;
        }
        let targetSessionId: string;
        let shouldReplaceMessages = false;
        if (sessionTarget.mode === 'append') {
          targetSessionId = sessionTarget.sessionId;
        } else {
          const newSession = await chatStorageService.createSession();
          const title = titleText;
          await chatStorageService.updateSession(newSession.id, { title });
          newSession.title = title;

          setSessions((prev) => [newSession, ...prev]);
          updateActiveSessionId(newSession.id);
          targetSessionId = newSession.id;
          shouldReplaceMessages = true;
        }

        // 创建用户消息（包含图片和视频）
        const timestamp = Date.now();
        const userMsgId = `msg_${timestamp}_user`;
        const userMsgParts: Message['parts'] = [
          { type: 'text', text: userDisplayText },
        ];

        // 添加参考图片
        const allImages = [
          ...context.selection.images,
          ...context.selection.graphics,
        ];
        for (let i = 0; i < allImages.length; i++) {
          userMsgParts.push({
            type: 'data-file',
            data: {
              filename: `image-${i + 1}.png`,
              mediaType: 'image/png',
              url: allImages[i],
            },
          } as any);
        }

        // 添加参考视频
        for (let i = 0; i < context.selection.videos.length; i++) {
          userMsgParts.push({
            type: 'data-file',
            data: {
              filename: `video-${i + 1}.mp4`,
              mediaType: 'video/mp4',
              url: context.selection.videos[i],
            },
          } as any);
        }

        const userMsg: Message = {
          id: userMsgId,
          role: 'user',
          parts: userMsgParts,
        };

        // 创建工作流消息（助手消息）
        const workflowMsgId = `msg_${timestamp}_workflow`;
        const workflowMsg: Message = {
          id: workflowMsgId,
          role: 'assistant',
          parts: [
            {
              type: 'text',
              text: `${WORKFLOW_MESSAGE_PREFIX}${workflowMsgId}`,
            },
          ],
        };

        // 只把当前会话的 workflow 写入内存；非当前会话只持久化，
        // 避免后台话题的任务状态污染当前话题。
        if (activeSessionIdRef.current === targetSessionId) {
          const nextWorkflowMessages = new Map(workflowMessagesRef.current);
          nextWorkflowMessages.set(workflowMsgId, workflow);
          workflowMessagesRef.current = nextWorkflowMessages;
          setWorkflowMessages(nextWorkflowMessages);
        }
        currentWorkflowMsgIdRef.current = workflowMsgId;
        currentWorkflowSessionIdRef.current = targetSessionId;

        // 持久化用户消息到本地存储
        const userChatMsg: ChatMessageType = {
          id: userMsgId,
          sessionId: targetSessionId,
          role: MessageRole.USER,
          content: userDisplayText,
          timestamp: Date.now(),
          status: MessageStatus.SUCCESS,
          aiContext: context, // 保存完整的上下文信息
          attachments:
            allImages.length > 0 || context.selection.videos.length > 0
              ? [
                  ...allImages.map((url, i) => ({
                    id: `${userMsgId}-img-${i}`,
                    name: `image-${i + 1}.png`,
                    type: 'image/png',
                    size: 0,
                    data: url,
                    isBlob: false,
                  })),
                  ...context.selection.videos.map((url, i) => ({
                    id: `${userMsgId}-vid-${i}`,
                    name: `video-${i + 1}.mp4`,
                    type: 'video/mp4',
                    size: 0,
                    data: url,
                    isBlob: false,
                  })),
                ]
              : undefined,
        };
        await chatStorageService.addMessage(userChatMsg);

        // 持久化工作流消息到本地存储
        const workflowChatMsg: ChatMessageType = {
          id: workflowMsgId,
          sessionId: targetSessionId,
          role: MessageRole.ASSISTANT,
          content: `${WORKFLOW_MESSAGE_PREFIX}${workflowMsgId}`,
          timestamp: Date.now(),
          status: MessageStatus.STREAMING,
          workflow: workflow,
        };
        await chatStorageService.addMessage(workflowChatMsg);

        const session = await chatStorageService.getSession(targetSessionId);
        const nextUpdatedAt = Date.now();
        const nextMessageCount = (session?.messageCount || 0) + 2;
        await chatStorageService.updateSession(targetSessionId, {
          updatedAt: nextUpdatedAt,
          messageCount: nextMessageCount,
        });
        setSessions((prev) =>
          prev.map((item) =>
            item.id === targetSessionId
              ? {
                  ...item,
                  updatedAt: nextUpdatedAt,
                  messageCount: nextMessageCount,
                }
              : item
          )
        );

        if (activeSessionIdRef.current !== targetSessionId) {
          return;
        }

        if (shouldReplaceMessages) {
          // 新建会话时直接替换为新会话消息。
          chatHandler.setMessagesWithRaw?.(
            [userMsg, workflowMsg],
            [userChatMsg, workflowChatMsg]
          );
        } else {
          // 抽屉内生成应留在当前会话，只追加消息，不跳到新会话。
          chatHandler.appendMessagesWithRaw?.(
            [userMsg, workflowMsg],
            [userChatMsg, workflowChatMsg]
          );
        }
      },
      [activeSessionId, chatHandler, onOpenChange, updateActiveSessionId]
    );

    const [shouldRenderChat, setShouldRenderChat] = useState(false);

    useEffect(() => {
      if (isOpen) {
        setShouldRenderChat(true);
      }
    }, [isOpen]);

    const implicitReferenceContent = useMemo(() => {
      if (replyTarget) {
        return getLatestWorkflowImageReferences([replyTarget.workflow]);
      }

      if (!shouldRenderChat) {
        return [];
      }

      return getLatestWorkflowImageReferences(workflowMessages.values());
    }, [replyTarget, shouldRenderChat, workflowMessages]);

    const implicitReferenceLabel = replyTarget
      ? `回复：${replyTarget.workflow.name || '生成结果'}`
      : undefined;

    const handleWorkflowReply = useCallback(
      (messageId: string, workflow: WorkflowMessageData) => {
        setReplyTarget({ messageId, workflow });
      },
      []
    );

    const handleClearReplyTarget = useCallback(() => {
      setReplyTarget(null);
    }, []);

    const handleSubmitDrawerGeneration = useCallback(
      async (message: Message) => {
        const textPart = message.parts.find((part) => part.type === 'text');
        const prompt =
          textPart && 'text' in textPart && typeof textPart.text === 'string'
            ? textPart.text
            : '';
        const hasFilePart = message.parts.some(
          (part) => part.type === 'data-file' || part.type === 'image_url'
        );

        if (
          !hasFilePart &&
          implicitReferenceContent.length > 0 &&
          (replyTarget || shouldUseImplicitWorkflowReferences(prompt))
        ) {
          const referenceParts: Message['parts'] = implicitReferenceContent
            .filter((item) => item.url)
            .map((item, index) => ({
              type: 'data-file' as const,
              data: {
                filename: `previous-result-${index + 1}.png`,
                mediaType: 'image/png',
                url: item.url,
              },
            }));

          await handleSendWrapper({
            ...message,
            parts: [...message.parts, ...referenceParts],
          });
          return;
        }

        await handleSendWrapper(message);
      },
      [handleSendWrapper, implicitReferenceContent, replyTarget]
    );

    // 更新当前工作流消息（同时持久化到本地存储）
    const handleUpdateWorkflowMessage = useCallback(
      async (workflow: WorkflowMessageData) => {
        let msgId = currentWorkflowMsgIdRef.current;
        let sessionId = currentWorkflowSessionIdRef.current;

        if (msgId) {
          const currentWorkflow = workflowMessagesRef.current.get(msgId);
          if (currentWorkflow && currentWorkflow.id === workflow.id) {
            sessionId = activeSessionIdRef.current;
          } else if (currentWorkflow && currentWorkflow.id !== workflow.id) {
            msgId = null;
            sessionId = null;
          }
        }

        if (!msgId) {
          const mappedMsgId = findWorkflowMessageIdInMap(
            workflowMessagesRef.current,
            workflow.id
          );
          if (mappedMsgId) {
            msgId = mappedMsgId;
            sessionId = activeSessionIdRef.current;
          }
        }

        if (!msgId) {
          const storedMessage = await chatStorageService.findWorkflowMessage(
            workflow.id
          );
          if (storedMessage) {
            msgId = storedMessage.id;
            sessionId = storedMessage.sessionId;
          }
        }

        if (!msgId) {
          return;
        }

        currentWorkflowMsgIdRef.current = msgId;
        currentWorkflowSessionIdRef.current = sessionId;

        if (!sessionId || sessionId === activeSessionIdRef.current) {
          const nextWorkflowMessages = new Map(workflowMessagesRef.current);
          nextWorkflowMessages.set(msgId, workflow);
          workflowMessagesRef.current = nextWorkflowMessages;
          setWorkflowMessages(nextWorkflowMessages);
          chatHandler.updateRawMessageWorkflow?.(msgId, workflow);
        }

        await chatStorageService.updateMessage(msgId, {
          workflow,
          status: getMessageStatusForWorkflow(workflow),
        });
      },
      [chatHandler]
    );

    const handleSyncWorkflowTaskUpdate = useCallback(
      (task: Task): boolean => {
        const currentWorkflowMessages = workflowMessagesRef.current;
        let targetMsgId: string | null = null;
        const targetSessionId: string | null = activeSessionIdRef.current;
        let updatedWorkflow: WorkflowMessageData | null = null;

        for (const [msgId, workflow] of currentWorkflowMessages.entries()) {
          const candidate = applyTaskUpdateToWorkflowMessage(workflow, task);
          if (candidate) {
            targetMsgId = msgId;
            updatedWorkflow = candidate;
            break;
          }
        }

        if (!targetMsgId || !updatedWorkflow) {
          if (pendingStoredWorkflowTaskSyncRef.current.has(task.id)) {
            return true;
          }
          pendingStoredWorkflowTaskSyncRef.current.add(task.id);
          void (async () => {
            const message = await chatStorageService.findWorkflowMessageByTask(
              (workflow) =>
                Boolean(applyTaskUpdateToWorkflowMessage(workflow, task))
            );
            if (!message?.workflow) {
              return;
            }

            const candidate = applyTaskUpdateToWorkflowMessage(
              message.workflow,
              task
            );
            if (!candidate) {
              return;
            }

            await chatStorageService.updateMessage(message.id, {
              workflow: candidate,
              status: getMessageStatusForWorkflow(candidate),
            });
            currentWorkflowMsgIdRef.current = message.id;
            currentWorkflowSessionIdRef.current = message.sessionId;

            if (activeSessionIdRef.current === message.sessionId) {
              const nextWorkflowMessages = new Map(workflowMessagesRef.current);
              nextWorkflowMessages.set(message.id, candidate);
              workflowMessagesRef.current = nextWorkflowMessages;
              setWorkflowMessages(nextWorkflowMessages);
              chatHandler.updateRawMessageWorkflow?.(message.id, candidate);
            }
          })()
            .catch((error) => {
              console.warn(
                '[ChatDrawer] Failed to sync stored workflow:',
                error
              );
            })
            .finally(() => {
              pendingStoredWorkflowTaskSyncRef.current.delete(task.id);
            });
          return true;
        }

        const nextWorkflowMessages = new Map(currentWorkflowMessages);
        nextWorkflowMessages.set(targetMsgId, updatedWorkflow);
        workflowMessagesRef.current = nextWorkflowMessages;
        currentWorkflowMsgIdRef.current = targetMsgId;
        currentWorkflowSessionIdRef.current = targetSessionId;
        if (
          !targetSessionId ||
          targetSessionId === activeSessionIdRef.current
        ) {
          setWorkflowMessages(nextWorkflowMessages);
        }

        chatStorageService.updateMessage(targetMsgId, {
          workflow: updatedWorkflow,
          status: getMessageStatusForWorkflow(updatedWorkflow),
        });
        if (
          !targetSessionId ||
          targetSessionId === activeSessionIdRef.current
        ) {
          chatHandler.updateRawMessageWorkflow?.(targetMsgId, updatedWorkflow);
        }

        return true;
      },
      [chatHandler]
    );

    // 追加 Agent 执行日志（同时持久化）
    const handleAppendAgentLog = useCallback(
      (log: AgentLogEntry) => {
        const msgId = currentWorkflowMsgIdRef.current;
        if (!msgId) return;

        setWorkflowMessages((prev) => {
          const newMap = new Map(prev);
          const workflow = newMap.get(msgId);
          if (workflow) {
            const logs = workflow.logs || [];
            const updatedWorkflow = {
              ...workflow,
              logs: [...logs, log],
            };
            newMap.set(msgId, updatedWorkflow);
            // 持久化到本地存储
            chatStorageService.updateMessage(msgId, {
              workflow: updatedWorkflow,
            });
            // 同步更新 chatHandler 中的原始消息
            chatHandler.updateRawMessageWorkflow?.(msgId, updatedWorkflow);
          }
          return newMap;
        });
      },
      [chatHandler]
    );

    // 更新 AI 思考内容（流式追加，使用防抖减少存储频率）
    const thinkingUpdateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const handleUpdateThinkingContent = useCallback(
      (content: string) => {
        const msgId = currentWorkflowMsgIdRef.current;
        if (!msgId) return;

        setWorkflowMessages((prev) => {
          const newMap = new Map(prev);
          const workflow = newMap.get(msgId);
          if (workflow) {
            const logs = workflow.logs || [];
            // 查找最后一个 thinking 日志（从后向前遍历）
            let lastThinkingIndex = -1;
            for (let i = logs.length - 1; i >= 0; i--) {
              if (logs[i].type === 'thinking') {
                lastThinkingIndex = i;
                break;
              }
            }

            let updatedWorkflow: WorkflowMessageData;
            if (lastThinkingIndex >= 0) {
              // 更新现有的 thinking 日志
              const updatedLogs = [...logs];
              const thinkingLog = updatedLogs[lastThinkingIndex] as Extract<
                AgentLogEntry,
                { type: 'thinking' }
              >;
              updatedLogs[lastThinkingIndex] = {
                ...thinkingLog,
                content: thinkingLog.content + content,
              };
              updatedWorkflow = { ...workflow, logs: updatedLogs };
            } else {
              // 创建新的 thinking 日志
              updatedWorkflow = {
                ...workflow,
                logs: [
                  ...logs,
                  { type: 'thinking' as const, timestamp: Date.now(), content },
                ],
              };
            }
            newMap.set(msgId, updatedWorkflow);

            // 防抖持久化（500ms 内只保存一次）
            if (thinkingUpdateTimeoutRef.current) {
              clearTimeout(thinkingUpdateTimeoutRef.current);
            }
            thinkingUpdateTimeoutRef.current = setTimeout(() => {
              chatStorageService.updateMessage(msgId, {
                workflow: updatedWorkflow,
              });
              // 同步更新 chatHandler 中的原始消息
              chatHandler.updateRawMessageWorkflow?.(msgId, updatedWorkflow);
            }, 500);
          }
          return newMap;
        });
      },
      [chatHandler]
    );

    // 处理工作流重试
    const handleWorkflowRetry = useCallback(
      async (
        workflowMsgId: string,
        workflow: WorkflowMessageData,
        stepIndex: number
      ) => {
        if (retryingWorkflowId) return; // 已经在重试中

        analytics.track('chat_workflow_retry', { stepIndex });

        try {
          setRetryingWorkflowId(workflowMsgId);
          // 设置当前工作流消息 ID，以便更新时能正确关联
          currentWorkflowMsgIdRef.current = workflowMsgId;
          // 调用注册的重试处理器
          await executeRetry(workflow, stepIndex);
        } finally {
          setRetryingWorkflowId(null);
        }
      },
      [executeRetry, retryingWorkflowId]
    );

    // Expose ref API for external control
    useImperativeHandle(
      ref,
      () => ({
        open: () => {
          setIsOpen(true);
          onOpenChange?.(true);
        },
        close: () => {
          setIsOpen(false);
          onOpenChange?.(false);
        },
        toggle: handleToggle,
        sendMessage: async (content: string) => {
          // Open drawer first
          setIsOpen(true);
          onOpenChange?.(true);

          // Create message object
          const msg: Message = {
            id: `msg_${Date.now()}`,
            role: 'user',
            parts: [{ type: 'text', text: content }],
          };

          // Send the message
          await handleSendWrapper(msg);
        },
        sendWorkflowMessage: handleSendWorkflowMessage,
        updateWorkflowMessage: handleUpdateWorkflowMessage,
        syncWorkflowTaskUpdate: handleSyncWorkflowTaskUpdate,
        appendAgentLog: handleAppendAgentLog,
        updateThinkingContent: handleUpdateThinkingContent,
        isOpen: () => isOpen,
        getActiveSessionId: () => activeSessionId,
        retryWorkflowFromStep: async (
          workflow: WorkflowMessageData,
          stepIndex: number
        ) => {
          // Find the message ID associated with this workflow
          let targetMsgId: string | null = null;
          for (const [msgId, wf] of workflowMessages.entries()) {
            if (wf.id === workflow.id) {
              targetMsgId = msgId;
              break;
            }
          }

          if (targetMsgId) {
            await handleWorkflowRetry(targetMsgId, workflow, stepIndex);
          } else {
            console.warn(
              '[ChatDrawer] Could not find message ID for workflow retry',
              workflow.id
            );
          }
        },
      }),
      [
        isOpen,
        activeSessionId,
        handleToggle,
        handleSendWrapper,
        handleSendWorkflowMessage,
        handleUpdateWorkflowMessage,
        handleSyncWorkflowTaskUpdate,
        handleAppendAgentLog,
        handleUpdateThinkingContent,
        onOpenChange,
        workflowMessages,
        handleWorkflowRetry,
      ]
    );

    // Wrapped handler for ChatSection
    const wrappedHandler = useMemo(
      () => ({
        ...chatHandler,
        sendMessage: handleSendWrapper,
      }),
      [chatHandler, handleSendWrapper]
    );

    // Get current session title
    const currentSession = sessions.find((s) => s.id === activeSessionId);
    const title = currentSession?.title || '新对话';

    const updateSessionInMemory = useCallback(
      (sessionId: string, updates: Partial<ChatSession>) => {
        setSessions((prev) =>
          prev.map((session) =>
            session.id === sessionId ? { ...session, ...updates } : session
          )
        );
      },
      []
    );

    const handleSessionModelChange = useCallback(
      (modelId: string, modelRef?: ModelRef | null) => {
        const nextModelRef = modelRef || createModelRef(null, modelId);
        setSessionModel(modelId);
        setSessionModelRef(nextModelRef);

        if (!activeSessionId) {
          return;
        }

        const updates: Partial<ChatSession> = {
          sessionModel: modelId,
          sessionModelRef: nextModelRef,
        };
        updateSessionInMemory(activeSessionId, updates);
        void chatStorageService.updateSession(activeSessionId, updates, {
          preserveUpdatedAt: true,
        });
      },
      [activeSessionId, updateSessionInMemory]
    );

    const handleGenerationStateChange = useCallback(
      (generationState: ChatSessionGenerationState) => {
        if (!activeSessionId) {
          return;
        }

        const updates: Partial<ChatSession> = { generationState };
        updateSessionInMemory(activeSessionId, updates);
        void chatStorageService.updateSession(activeSessionId, updates, {
          preserveUpdatedAt: true,
        });
      },
      [activeSessionId, updateSessionInMemory]
    );

    const handleDraftChange = useCallback(
      (
        sessionId: string,
        draft: {
          draftInput: string;
          draftUploadedContent: SelectedContentItem[];
        }
      ) => {
        const updates: Partial<ChatSession> = {
          draftInput: draft.draftInput,
          draftUploadedContent: sanitizeDraftUploadedContent(
            draft.draftUploadedContent
          ),
        };
        updateSessionInMemory(sessionId, updates);
        void chatStorageService.updateSession(sessionId, updates, {
          preserveUpdatedAt: true,
        });
      },
      [updateSessionInMemory]
    );

    // 标题编辑状态
    const [isEditingTitle, setIsEditingTitle] = useState(false);
    const [editingTitleValue, setEditingTitleValue] = useState('');
    const titleInputRef = useRef<HTMLInputElement>(null);

    // 开始编辑标题
    const handleStartEditTitle = useCallback(() => {
      setEditingTitleValue(title);
      setIsEditingTitle(true);
    }, [title]);

    // 保存标题
    const handleSaveTitle = useCallback(async () => {
      const trimmedValue = editingTitleValue.trim();
      if (trimmedValue && trimmedValue !== title && activeSessionId) {
        await handleRenameSession(activeSessionId, trimmedValue);
      }
      setIsEditingTitle(false);
    }, [editingTitleValue, title, activeSessionId, handleRenameSession]);

    // 取消编辑标题
    const handleCancelEditTitle = useCallback(() => {
      setEditingTitleValue(title);
      setIsEditingTitle(false);
    }, [title]);

    // 标题输入框按键处理
    const handleTitleKeyDown = useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleSaveTitle();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          handleCancelEditTitle();
        }
      },
      [handleSaveTitle, handleCancelEditTitle]
    );

    // 自动聚焦标题输入框
    useEffect(() => {
      if (isEditingTitle && titleInputRef.current) {
        titleInputRef.current.focus();
        titleInputRef.current.select();
      }
    }, [isEditingTitle]);

    useEffect(() => {
      setIsEditingTitle(false);
      setEditingTitleValue('');
    }, [activeSessionId]);

    const domRef = useRef<HTMLDivElement>(null);
    // 使用自定义 hook 处理文本选择和复制，同时阻止事件冒泡
    useTextSelection(domRef, {
      enableCopy: true,
      stopPropagation: true,
    });

    return (
      <>
        <ChatDrawerTrigger
          isOpen={isOpen}
          onClick={handleToggle}
          drawerWidth={drawerWidth}
        />

        <div
          className={`chat-drawer ${ATTACHED_ELEMENT_CLASS_NAME} ${
            isOpen ? 'chat-drawer--open' : ''
          } ${isDragging ? 'chat-drawer--dragging' : ''}`}
          style={{ width: drawerWidth }}
          data-testid="chat-drawer"
        >
          {/* 拖动调整宽度的手柄 */}
          <div
            ref={resizeHandleRef}
            className="chat-drawer__resize-handle"
            onMouseDown={handleResizeStart}
          />
          <div ref={domRef} className="chat-drawer__body">
            <div className="chat-drawer__header">
              <div className="chat-drawer__header-top">
                <HoverTip content="关闭">
                  <button
                    className="chat-drawer__close-btn"
                    data-track="chat_click_drawer_close"
                    onClick={handleClose}
                    aria-label="关闭对话"
                  >
                    <CloseIcon size={16} />
                  </button>
                </HoverTip>
                {isEditingTitle ? (
                  <input
                    ref={titleInputRef}
                    className="chat-drawer__title-input"
                    value={editingTitleValue}
                    onChange={(e) => setEditingTitleValue(e.target.value)}
                    onKeyDown={handleTitleKeyDown}
                    onBlur={handleSaveTitle}
                    maxLength={50}
                  />
                ) : (
                  <HoverTip content="点击编辑标题" showArrow={false}>
                    <h2
                      className="chat-drawer__title chat-drawer__title--editable"
                      onClick={handleStartEditTitle}
                    >
                      {title}
                    </h2>
                  </HoverTip>
                )}
              </div>
              <div className="chat-drawer__header-bottom">
                <ModelSelector
                  value={sessionModel}
                  valueRef={sessionModelRef}
                  onChange={handleSessionModelChange}
                />
                <div className="chat-drawer__session-actions">
                  <HoverTip content="会话列表">
                    <button
                      ref={toggleButtonRef}
                      className={`chat-drawer__close-btn ${
                        showSessions ? 'chat-drawer__close-btn--active' : ''
                      }`}
                      data-track="chat_click_sessions_toggle"
                      onClick={handleToggleSessions}
                      aria-label="会话列表"
                    >
                      <ViewListIcon size={16} />
                    </button>
                  </HoverTip>
                  <HoverTip content="新对话">
                    <button
                      className="chat-drawer__close-btn"
                      data-track="chat_click_new_session"
                      onClick={handleNewSession}
                      aria-label="新对话"
                    >
                      <AddIcon size={16} />
                    </button>
                  </HoverTip>
                </div>
              </div>
            </div>

            {showSessions && (
              <div ref={sessionListRef}>
                <SessionList
                  sessions={sessions}
                  activeSessionId={activeSessionId}
                  onSelectSession={handleSelectSession}
                  onNewSession={handleNewSession}
                  onDeleteSession={handleDeleteSession}
                  onRenameSession={handleRenameSession}
                />
              </div>
            )}

            <div className="chat-drawer__content">
              {shouldRenderChat && (
                <Suspense
                  fallback={
                    <div className="chat-loading chat-loading--full">
                      <div className="chat-loading__spinner" />
                    </div>
                  }
                >
                  <ChatMessagesArea
                    handler={wrappedHandler}
                    workflowMessages={workflowMessages}
                    retryingWorkflowId={retryingWorkflowId}
                    handleWorkflowReply={handleWorkflowReply}
                    handleWorkflowRetry={handleWorkflowRetry}
                  />
                </Suspense>
              )}

              <EnhancedChatInput
                activeSessionId={activeSessionId}
                selectedContent={selectedContent}
                implicitReferenceContent={implicitReferenceContent}
                implicitReferenceLabel={implicitReferenceLabel}
                implicitReferencePinned={Boolean(replyTarget)}
                onClearImplicitReference={
                  replyTarget ? handleClearReplyTarget : undefined
                }
                onImplicitReferenceConsumed={
                  replyTarget ? handleClearReplyTarget : undefined
                }
                generationState={currentSession?.generationState || null}
                draftInput={currentSession?.draftInput || ''}
                draftUploadedContent={
                  currentSession?.draftUploadedContent || []
                }
                onGenerationStateChange={handleGenerationStateChange}
                onDraftChange={handleDraftChange}
                onSend={handleSubmitDrawerGeneration}
                onGenerationSubmit={handleGenerationSubmit}
                placeholder="继续描述要修改的内容..."
              />
            </div>
          </div>
        </div>
      </>
    );
  }
);

ChatDrawer.displayName = 'ChatDrawer';
