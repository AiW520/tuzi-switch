# CC Switch User Manual / 用户手册 / ユーザーマニュアル

> Claude Code / Codex / Gemini CLI / OpenCode / OpenClaw

## Language / 语言 / 言語

| Language | Link |
|----------|------|
| [中文](./zh/README.md) | 简体中文用户手册 |
| [English](./en/README.md) | English User Manual |
| [日本語](./ja/README.md) | 日本語ユーザーマニュアル |

## Version / 版本 / バージョン

- Documentation version: v3.15.0
- Last updated: 2026-05-16
- Compatible with CC Switch v3.15.0+

## Links

- [GitHub Issues](https://github.com/farion1231/cc-switch/issues)
- [GitHub Repository](https://github.com/farion1231/cc-switch)
